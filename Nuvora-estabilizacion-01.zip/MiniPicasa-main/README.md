# MiniPicasa
Picasa for Android
